package com.example.a1;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FragmentMycollect extends Fragment {

    private TextView textView;
    private Button share;
    private EditText editText;
    private EditText title;
    private List<TextView> saveTextViews;
    private int currentIndex = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mycollect, container, false);

        textView = view.findViewById(R.id.editTextText1);
        share = view.findViewById(R.id.button2);
        editText = view.findViewById(R.id.editTextText2);
        title = view.findViewById(R.id.textView2);

        saveTextViews = new ArrayList<>();
        saveTextViews.add(view.findViewById(R.id.save));
        saveTextViews.add(view.findViewById(R.id.save2));
        saveTextViews.add(view.findViewById(R.id.save3));
        saveTextViews.add(view.findViewById(R.id.save4));
        saveTextViews.add(view.findViewById(R.id.save5));
        saveTextViews.add(view.findViewById(R.id.save6));
        saveTextViews.add(view.findViewById(R.id.save7));
        saveTextViews.add(view.findViewById(R.id.save8));
        saveTextViews.add(view.findViewById(R.id.save9));

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = editText.getText().toString();
                String Title = title.getText().toString();
                String Text = Title + " - \n " + inputText;

                if (currentIndex < saveTextViews.size()) {
                    TextView textView = saveTextViews.get(currentIndex);
                    textView.setText(Text);
                    makeTextViewLinkable(textView);
                    currentIndex++;
                    editText.getText().clear();
                    title.getText().clear();
                } else {
                    saveTextViews.get(0).setText(inputText);
                    makeTextViewLinkable(saveTextViews.get(0));
                    currentIndex = 1;
                    editText.getText().clear();
                }
            }
        });

        return view;
    }

    private void makeTextViewLinkable(TextView textView) {
        SpannableString spannableString = new SpannableString(textView.getText());
        Linkify.addLinks(spannableString, Linkify.WEB_URLS);
        textView.setText(spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    @Override
    public void onResume() {
        super.onResume();
        if (localeChanged()) {
            requireActivity().recreate();
        }
        applyTextSizeFromPreferences();
        updateBackgroundColor();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        updateLocale(context);
    }

    private void updateLocale(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("AppSettings", Context.MODE_PRIVATE);
        String language = prefs.getString("user_language", "en");
        String country = prefs.getString("user_country", "US");
        Locale locale = new Locale(language, country);
        Locale.setDefault(locale);
        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }

    private boolean localeChanged() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("AppSettings", Context.MODE_PRIVATE);
        String currentLanguage = getResources().getConfiguration().getLocales().get(0).getLanguage();
        String savedLanguage = prefs.getString("user_language", currentLanguage);
        return !currentLanguage.equals(savedLanguage);
    }

    private void applyTextSizeFromPreferences() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(ChangeColorFragment.PREFS_NAME, Context.MODE_PRIVATE);
        float textSize = sharedPreferences.getFloat(ChangeColorFragment.TEXT_SIZE_KEY, 18f);  // Default size

        Button buttonEnter = requireView().findViewById(R.id.button2);
        EditText textView1 = requireView().findViewById(R.id.editTextText1);
        EditText textView2 = requireView().findViewById(R.id.editTextText2);
        TextView textView3 = requireView().findViewById(R.id.save);
        TextView textView4 = requireView().findViewById(R.id.save2);
        TextView textView5 = requireView().findViewById(R.id.save3);
        TextView textView6 = requireView().findViewById(R.id.save4);
        TextView textView7 = requireView().findViewById(R.id.save5);
        TextView textView8 = requireView().findViewById(R.id.save6);
        TextView textView9 = requireView().findViewById(R.id.save7);
        TextView textView10 = requireView().findViewById(R.id.save8);
        TextView textView11 = requireView().findViewById(R.id.save9);
        textView11.setTextSize(textSize);
        textView10.setTextSize(textSize);
        textView9.setTextSize(textSize);
        textView8.setTextSize(textSize);
        textView7.setTextSize(textSize);
        textView6.setTextSize(textSize);
        textView5.setTextSize(textSize);
        textView4.setTextSize(textSize);
        textView3.setTextSize(textSize);
        buttonEnter.setTextSize(textSize);
        textView1.setTextSize(textSize);
        textView2.setTextSize(textSize);
    }

    private void updateBackgroundColor() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("appPreferences", Context.MODE_PRIVATE);
        int defaultBackgroundColor = ContextCompat.getColor(requireContext(), R.color.背景);
        int backgroundColor = prefs.getInt("background_color", defaultBackgroundColor);
        requireView().findViewById(R.id.drawer_layout).setBackgroundColor(backgroundColor);

        ImageButton imageButton1 = requireView().findViewById(R.id.imageButton8);
        imageButton1.setBackgroundTintList(ColorStateList.valueOf(backgroundColor));

        ImageButton imageButton2 = requireView().findViewById(R.id.imageButton6);
        imageButton2.setBackgroundTintList(ColorStateList.valueOf(backgroundColor));

        ImageButton imageButton3 = requireView().findViewById(R.id.imageButton9);
        imageButton3.setBackgroundTintList(ColorStateList.valueOf(backgroundColor));
    }
}
package com.example.a1;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity

{

}
